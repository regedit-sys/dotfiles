echo "---" | tee /tmp/polybar.log
polybar top 2>&1 | tee -a /tmp/polybar.log & disown
echo "bars launched!"
